var connection = require('./../config');
module.exports.register=function(req,res){
  
    var account={
        "username":req.body.username,
        "email":req.body.email,
        "password":req.body.password,
        "dob" : req.body.dob,
        "gender" : req.body.gender,
        "created_at" : new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '') 
    }
    connection.query('INSERT INTO account SET ?',account, function (error, results, fields) {
      if (error) {
          console.log(error);
        res.json({
            status:false,
            message:'there are some error with query',
        })
      }else{
          return res.redirect('/welcome');
      }
    });
}