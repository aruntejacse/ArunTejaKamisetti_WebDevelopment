create database intership;
use intership;


create table account(
username varchar(50) NOT NULL,
email varchar(100) primary KEY NOT NULL,
password varchar(255) NOT NULL,
dob varchar(20) not null,
gender varchar(10) not null,
created_at timestamp DEFAULT CURRENT_TIMESTAMP
);

select * from account;
