-----SIGN UP FORM ----

FILE STRUCTURE :

root
|
|_controllers
    |_register-controller.js   ----// Javascript file where the code to insert data into database is written.
|_node_modules                 ----// Node packages and submodules used throughout the project
|_public
    |_bg1.jpg                   ---|
    |_bg2.jpg                   ---|
    |_download.jpg              ---|---- images used in this project
    |_download1.jpg             ---|
    |_login.png                 ---|
    |_global.css                ----//css file for index.html(the sign up page) 
    |_style.css                 ----//css file for welcome page(the redirect page)
    |_signup.js                 ----//js file for index.html
|
|_config.js                 ----//setup file that sets up connection with database(mysql)
|_index.html                ----//sign up page
|_index.js                  ----//handling imports and static files  
|_package.json              ----//json file 1
|_package-lock.json         ----//json file 2
|_welcome.html              ----//welcome page
|_account.sql               ----//database queries(creation of table in mysql)
|_screenshots               ----//images of working code in my localhost

DESCRIPTION :
        --First, you will enter the sign up page which asks for 
                    1) Fullname [Validation is done : Only lowercase and uppercase letters are allowed]
                    2) Email [Validation is done : @ symbol should be present]
                    3) Password [Validation is done : One uppercase,one lowercase and one number is must] 
                    {You can also toggle view the password}
                    4)DOB [Validation is done : Compulsory required field that uses calender to select date for better interface]
                    5) Gender [Validation is done : Compulsory field]

                    Appropriate error messages will be displayed accordingly.

        After the user submits the valid inputs, the user will be redirected to welcome page. All the user details along with the
        timestamp are stored inside 'account' table i created in my mysql database. User can also logout which redirects him to signip page.

TIME TAKEN :
1.5 DAYS(not completely)

TOOLS USED :
HTML5, CSS, JAVASCRIPT, BOOTSTRAP4, NODEJS, EXPRESSJS, MYSQL