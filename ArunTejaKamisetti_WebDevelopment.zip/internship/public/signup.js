//function to toggle password visibility

function myFunction() {
    var x = document.getElementById("exampleInputPassword1");
    var y = document.getElementById("hide1");
    var z = document.getElementById("hide2");
    if (x.type === "password") {
      x.type = "text";
      y.style.display = "block";
      z.style.display = "none";
    } else {
        x.type = "password";
        y.style.display = "none";
        z.style.display = "block";
    }
  }


//form validation utility function

(function() {
  'use strict';
  window.addEventListener('load', function() {
    // fetch all the forms we want to apply custom style
    var inputs = document.getElementsByClassName('form-control')

    // loop over each input and watch blur event
    var validation = Array.prototype.filter.call(inputs, function(input) {

      input.addEventListener('blur', function(event) {
        // reset
        input.classList.remove('is-invalid')
        input.classList.remove('is-valid')

        if (input.checkValidity() === false) {
            input.classList.add('is-invalid');
            
        }
        else {
            input.classList.add('is-valid')
        }
      }, false);
    });
  }, false);
})()


