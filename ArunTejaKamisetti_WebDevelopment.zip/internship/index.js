var express=require("express");
var bodyParser=require('body-parser');


var connection = require('./config');
var app = express();
var path=require('path');




var registerController=require('./controllers/register-controller');
 

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.get('/', function (req, res) {  
   res.sendFile( __dirname + "/" + "index.html" );  
});

app.get('/welcome', function(request, response) {
	response.sendFile(path.join(__dirname + "/welcome.html"));
});
 

app.use(express.static(__dirname +'/public'));
/* route to handle login and registration */
app.post('/api/register',registerController.register);

 

app.post('/controllers/register-controller', registerController.register);

app.listen(8012);
